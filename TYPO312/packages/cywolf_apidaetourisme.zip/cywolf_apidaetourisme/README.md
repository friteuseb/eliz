# cywolf_apidaetourisme

Extension TYPO3 pour importer et afficher des données touristiques depuis Apidae.

## Installation

1. Placez l'extension dans le dossier `typo3conf/ext/`.
2. Activez l'extension dans le gestionnaire d'extensions de TYPO3.
3. Configurez le plugin via TypoScript si nécessaire.

## Utilisation

- Utilisez le plugin frontend `EtablissementList` pour afficher les fiches d'hébergement.
- Uploadez un fichier ZIP contenant les fichiers JSON via le backend pour importer les données.
- Configurez un Scheduler Task pour exécuter la commande `hebergement:importzip` après chaque upload.
