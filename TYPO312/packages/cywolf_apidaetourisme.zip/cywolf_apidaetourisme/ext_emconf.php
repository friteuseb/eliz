<?php

$EM_CONF[$_EXTKEY] = [
    'title' => 'Apidae Tourisme',
    'description' => 'Extension pour importer et afficher des données touristiques depuis Apidae.',
    'category' => 'plugin',
    'author' => 'Cywolf',
    'author_email' => 'contact@cywolf.com',
    'state' => 'stable',
    'version' => '1.0.0',
    'constraints' => [
        'depends' => [
            'typo3' => '12.4.0-12.4.99',
            'extbase' => '12.4.0-12.4.99',
            'fluid' => '12.4.0-12.4.99',
        ],
    ],
];