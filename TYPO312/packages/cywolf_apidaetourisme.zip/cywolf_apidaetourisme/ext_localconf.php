<?php
defined('TYPO3') or die();

(function () {
    \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
        'CywolfApidaetourisme',  // Cette syntaxe exacte est très importante
        'EtablissementList',
        [
            \Cywolf\ApidaeTourisme\Controller\EtablissementController::class => 'list,show',
        ],
        [
            \Cywolf\ApidaeTourisme\Controller\EtablissementController::class => '',
        ]
    );
})();