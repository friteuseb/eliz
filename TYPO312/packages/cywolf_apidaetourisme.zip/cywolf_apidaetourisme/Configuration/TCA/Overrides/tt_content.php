<?php
defined('TYPO3') or die();

(function () {
    // La signature du plugin qui sera utilisée pour le type TCA
    $pluginSignature = 'tx_cywolfapidaetourisme_etablissementlist';
    
    \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
        'CywolfApidaetourisme',  // Exactement comme dans ext_localconf.php!
        'EtablissementList',
        'Liste des établissements Apidae'
    );
    
    $GLOBALS['TCA']['tt_content']['types'][$pluginSignature]['showitem'] = '
        --div--;LLL:EXT:core/Resources/Private/Language/Form/locallang_tabs.xlf:general,
            --palette--;;general,
            --palette--;;headers,
        --div--;LLL:EXT:frontend/Resources/Private/Language/locallang_ttc.xlf:tabs.plugin,
        --div--;LLL:EXT:core/Resources/Private/Language/Form/locallang_tabs.xlf:language,
            --palette--;;language,
        --div--;LLL:EXT:core/Resources/Private/Language/Form/locallang_tabs.xlf:access,
            --palette--;;hidden,
            --palette--;;access,
    ';
})();