<?php
return [
    'cywolf:apidae:importslugs' => [ 
        'class' => \Cywolf\ApidaeTourisme\Command\ApidaeImportCommand::class,
    ],
];