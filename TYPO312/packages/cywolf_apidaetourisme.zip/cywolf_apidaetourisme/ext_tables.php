<?php
defined('TYPO3') or die();
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addStaticFile(
    'cywolf_apidaetourisme', // Clé de l'extension
    'Configuration/TypoScript',
    'Apidae Tourisme' // Titre du TypoScript statique dans le backend
);