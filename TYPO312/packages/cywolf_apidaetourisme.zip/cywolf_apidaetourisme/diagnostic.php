<?php
// Placez ce fichier à la racine de votre extension et exécutez-le via la console (php diagnostic.php)

echo "=== DIAGNOSTIC DE L'EXTENSION APIDAE TOURISME ===\n\n";

// 1. Vérifier composer.json
$composerJson = file_exists('composer.json') ? json_decode(file_get_contents('composer.json'), true) : null;
echo "Composer.json: " . ($composerJson ? "✓ Trouvé\n" : "❌ Non trouvé\n");
if ($composerJson) {
    echo "  - Nom du package: " . ($composerJson['name'] ?? 'Non défini') . "\n";
    echo "  - Extension key: " . ($composerJson['extra']['typo3/cms']['extension-key'] ?? 'Non définie') . "\n";
    echo "  - Namespace: " . (key_exists('autoload', $composerJson) && key_exists('psr-4', $composerJson['autoload']) ? array_keys($composerJson['autoload']['psr-4'])[0] : 'Non défini') . "\n";
}

// 2. Vérifier ext_emconf.php
$extEmconf = file_exists('ext_emconf.php') ? file_get_contents('ext_emconf.php') : null;
echo "\next_emconf.php: " . ($extEmconf ? "✓ Trouvé\n" : "❌ Non trouvé\n");
if ($extEmconf) {
    preg_match('/\'title\'\s*=>\s*\'([^\']+)\'/', $extEmconf, $matches);
    echo "  - Titre: " . ($matches[1] ?? 'Non trouvé') . "\n";
}

// 3. Vérifier ext_localconf.php
$extLocalconf = file_exists('ext_localconf.php') ? file_get_contents('ext_localconf.php') : null;
echo "\next_localconf.php: " . ($extLocalconf ? "✓ Trouvé\n" : "❌ Non trouvé\n");
if ($extLocalconf) {
    preg_match('/configurePlugin\(\s*\'([^\']+)\'/', $extLocalconf, $matches);
    echo "  - Extension name dans configurePlugin: " . ($matches[1] ?? 'Non trouvé') . "\n";
    
    preg_match('/\'([^\']+)\',[^,]*\/\/\s*<-\s*Bonne clé/', $extLocalconf, $matches);
    echo "  - Extension key commentée: " . ($matches[1] ?? 'Non trouvé') . "\n";
}

// 4. Vérifier TCA Overrides
$tcaOverrides = file_exists('Configuration/TCA/Overrides/tt_content.php') ? file_get_contents('Configuration/TCA/Overrides/tt_content.php') : null;
echo "\nConfiguration/TCA/Overrides/tt_content.php: " . ($tcaOverrides ? "✓ Trouvé\n" : "❌ Non trouvé\n");
if ($tcaOverrides) {
    preg_match('/\'([^\']+)\'\s*\/\/\s*<-\s*Bonne clé/', $tcaOverrides, $matches);
    echo "  - Extension key commentée: " . ($matches[1] ?? 'Non trouvé') . "\n";
    
    preg_match('/registerPlugin\(\s*\'([^\']+)\'/', $tcaOverrides, $matches1);
    preg_match('/addPlugin\(\s*\[\s*\'([^\']+)\'/', $tcaOverrides, $matches2);
    echo "  - Extension name dans registerPlugin/addPlugin: " . ($matches1[1] ?? $matches2[1] ?? 'Non trouvé') . "\n";
    
    preg_match('/pluginSignature\s*=\s*\'([^\']+)\'/', $tcaOverrides, $matches);
    echo "  - Plugin signature: " . ($matches[1] ?? 'Non trouvé') . "\n";
}

// 5. Vérifier TypoScript
$typoscriptSetup = file_exists('Configuration/TypoScript/setup.typoscript') ? file_get_contents('Configuration/TypoScript/setup.typoscript') : null;
echo "\nConfiguration/TypoScript/setup.typoscript: " . ($typoscriptSetup ? "✓ Trouvé\n" : "❌ Non trouvé\n");
if ($typoscriptSetup) {
    preg_match('/plugin\.tx_([a-zA-Z0-9_]+)\s*{/', $typoscriptSetup, $matches);
    echo "  - Extension name dans TypoScript: tx_" . ($matches[1] ?? 'Non trouvé') . "\n";
}

echo "\n=== RECOMMANDATIONS ===\n";
echo "Selon les informations collectées, voici les valeurs qui devraient être cohérentes:\n";

$extensionKey = $composerJson['extra']['typo3/cms']['extension-key'] ?? 'cywolf_apidaetourisme';
$extensionName = str_replace('_', '', ucwords(str_replace('_', ' ', $extensionKey)));
$pluginName = 'EtablissementList';
$pluginSignature = 'tx_' . strtolower(str_replace('_', '', $extensionKey)) . '_' . strtolower($pluginName);

echo "Extension key: $extensionKey\n";
echo "Extension name (pour configurePlugin/registerPlugin): $extensionName\n";
echo "Plugin name: $pluginName\n";
echo "Plugin signature: $pluginSignature\n";
echo "Namespace PHP: Cywolf\\ApidaeTourisme\\\n";
echo "TypoScript plugin path: plugin.$pluginSignature\n";