<?php
declare(strict_types=1);

namespace Cywolf\ApidaeTourisme\Controller;

use Psr\Log\LoggerInterface;

use TYPO3\CMS\Extbase\Mvc\Controller\ActionController;
use Cywolf\ApidaeTourisme\Service\ApidaeService;
use Psr\Http\Message\ResponseInterface;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Core\Messaging\AbstractMessage;

class EtablissementController extends ActionController
{
    protected ApidaeService $apidaeService;
    protected LoggerInterface $logger;

    public function __construct(ApidaeService $apidaeService, LoggerInterface $logger)
    {
        $this->apidaeService = $apidaeService;
        // Assigner le logger injecté à la propriété de la classe
        $this->logger = $logger;
    }

    /**
     * Action pour afficher la liste des objets Apidae.
     */
    public function listAction(): ResponseInterface
    {
        $etablissementsData = [];
        $errorOccurred = false;

        // Récupérer les settings TypoScript
        $settings = $this->settings;
        $this->view->assign('settings', $settings);

        // Récupérer et parser les selectionIds depuis les settings TypoScript
        $selectionIdsSetting = $settings['apidae']['selectionIds'] ?? '';
        $selectionIds = GeneralUtility::intExplode(',', $selectionIdsSetting, true);

        if (!empty($selectionIds)) {
            // Nombre d'éléments par page
            $itemsPerPage = (int)($settings['itemsPerPage'] ?? 12);

            // Appeler notre service pour récupérer les données de l'API
            $apiResult = $this->apidaeService->fetchObjectsBySelections($selectionIds, $itemsPerPage);

            if ($apiResult !== null && isset($apiResult['objetsTouristiques'])) {
                $etablissementsData = $apiResult['objetsTouristiques'];
                $this->view->assign('totalItems', $apiResult['numFound'] ?? 0);
            } else {
                $this->addFlashMessage(
                    'Impossible de récupérer les données depuis APIDAE. Vérifiez la configuration et les logs.',
                    'Erreur API',
                    AbstractMessage::ERROR
                );
                $errorOccurred = true;
            }
        } else {
            $this->addFlashMessage(
                'Aucun ID de sélection Apidae n\'est configuré dans les réglages TypoScript (settings.apidae.selectionIds).',
                'Erreur Configuration',
                AbstractMessage::WARNING
            );
            $errorOccurred = true;
        }

        $this->view->assign('etablissementsData', $etablissementsData);
        $this->view->assign('errorOccurred', $errorOccurred);

        return $this->htmlResponse();
    }

/**
 * Action pour afficher les détails d'un objet APIDAE.
 *
 * @param int $apidaeId L'identifiant unique de l'objet APIDAE passé dans l'URL
 */
public function showAction(int $apidaeId): ResponseInterface
{
    $etablissementData = null; // Initialiser
    $errorOccurred = false;

    if ($apidaeId > 0) {
        // === NOUVELLE LOGIQUE : Appel direct à fetchObjectById ===
        $this->logger?->info('Fetching details for Apidae ID: ' . $apidaeId); // Optional: add logger property if needed elsewhere
        $etablissementData = $this->apidaeService->fetchObjectById($apidaeId);

        if ($etablissementData === null) {
             // L'objet n'a pas été trouvé par le service OU une erreur API est survenue (déjà logguée par le service)
             $this->addFlashMessage(
                'Impossible de récupérer les détails pour l\'établissement demandé (ID: ' . $apidaeId . ').',
                'Objet Non Trouvé ou Erreur API',
                AbstractMessage::ERROR
             );
             $errorOccurred = true;
        }
        // === FIN NOUVELLE LOGIQUE ===

    } else {
        $this->addFlashMessage('Identifiant Apidae invalide fourni.', 'Erreur', AbstractMessage::ERROR);
        $errorOccurred = true;
    }

    // Assigner le résultat (tableau de l'objet unique ou null) à la vue
    $this->view->assign('etablissementData', $etablissementData);
    $this->view->assign('errorOccurred', $errorOccurred);

    return $this->htmlResponse();
}
}