<?php
declare(strict_types=1);

namespace Cywolf\ApidaeTourisme\Service;

use Psr\Log\LoggerInterface;
use TYPO3\CMS\Core\Http\RequestFactory;
use TYPO3\CMS\Core\Log\LogManager;
use TYPO3\CMS\Core\Site\SiteFinder; // Gardé si vous voulez utiliser Site Config plus tard
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface;

/**
 * Service pour interagir avec l'API Apidae Tourisme.
 */
class ApidaeService
{
    private LoggerInterface $logger;
    private RequestFactory $requestFactory;
    private ConfigurationManagerInterface $configurationManager;
    private SiteFinder $siteFinder;

    // Configuration API (sera écrasée par loadConfiguration)
    private string $apiKey = ''; // Sera chargé depuis les settings
    private int $projectId = 0;  // Sera chargé depuis les settings
    private string $searchApiUrl = 'https://api.apidae-tourisme.com/api/v002/recherche/list-objets-touristiques'; // URL pour la recherche/liste
    // Définir aussi l'URL pour get-by-id si elle est différente et utilisée dans fetchObjectById
    // private string $detailApiUrl = 'https://api.apidae-tourisme.com/api/v002/objet-touristique/get-by-id';

    public function __construct(
        RequestFactory $requestFactory,
        ConfigurationManagerInterface $configurationManager,
        SiteFinder $siteFinder,
        ?LoggerInterface $logger = null
    ) {
        $this->requestFactory = $requestFactory;
        $this->configurationManager = $configurationManager;
        $this->siteFinder = $siteFinder;
        $this->logger = $logger ?? GeneralUtility::makeInstance(LogManager::class)->getLogger(__CLASS__);
        $this->loadConfiguration();
    }

    /**
     * Charge la configuration API depuis les settings TypoScript.
     */
    private function loadConfiguration(): void
    {
        try {
            // Lire les settings TypoScript définis pour l'extension
            // (ex: plugin.tx_cywolfapidaetourisme.settings.apidae...)
            $settings = $this->configurationManager->getConfiguration(
                ConfigurationManagerInterface::CONFIGURATION_TYPE_SETTINGS
                // Pas besoin de clé d'extension ici, car on lit TOUS les settings,
                // mais il FAUT que la structure TS soit correcte (plugin.tx_...settings.apidae...)
            );

            if (isset($settings['apidae'])) {
                $this->apiKey = trim($settings['apidae']['apiKey'] ?? '');
                $this->projectId = (int)($settings['apidae']['projectId'] ?? 0);
                // Permettre de surcharger l'URL de recherche via TS si besoin
                $this->searchApiUrl = trim($settings['apidae']['apiUrl'] ?? $this->searchApiUrl);
                // $this->detailApiUrl = trim($settings['apidae']['apiDetailUrl'] ?? $this->detailApiUrl);

                if (empty($this->apiKey) || $this->projectId <= 0) {
                     $this->logger->error('Clé API ou ID Projet Apidae manquant/invalide dans les settings TypoScript.');
                     // Fallback extrême si mauvaise config (à éviter en production)
                     $this->apiKey = 'k7mrsOXH'; // Valeur codée en dur comme ultime recours
                     $this->projectId = 4324;  // Valeur codée en dur comme ultime recours
                } else {
                    $this->logger->info('Configuration Apidae chargée depuis les settings TS.');
                }
            } else {
                 $this->logger->warning('Bloc [apidae] non trouvé dans les settings TypoScript. Vérifiez votre setup.typoscript. Utilisation des valeurs par défaut codées en dur (non recommandé).');
                 // Fallback extrême
                 $this->apiKey = 'k7mrsOXH';
                 $this->projectId = 4324;
            }
        } catch (\Exception $e) {
            $this->logger->error('Erreur chargement configuration Apidae: ' . $e->getMessage());
            // Fallback extrême
            $this->apiKey = 'k7mrsOXH';
            $this->projectId = 4324;
        }
        // Log initial pour confirmer les valeurs utilisées (clé masquée)
         $this->logger->warning('ApidaeService Initialized.', [
             'apiKeyUsed' => substr($this->apiKey, 0, 3) . '...',
             'projectIdUsed' => $this->projectId,
             'searchApiUrlUsed' => $this->searchApiUrl
         ]);
    }

    /**
     * Récupère plusieurs objets pour la vue liste.
     *
     * @param array $selectionIds IDs de sélection Apidae
     * @param int $count Nombre max d'objets
     * @param array $responseFields Champs API à récupérer pour la liste
     * @return array|null Données API complètes (incluant 'numFound', 'objetsTouristiques', etc.) ou null si erreur
     */
    public function fetchObjectsBySelections(
        array $selectionIds,
        int $count = 20,
        // Liste par défaut des champs requis, incluant ceux pour la carte et les étoiles
        array $responseFields = [
            'id', 'nom', 'type',
            'localisation.adresse', 'localisation.geolocalisation', // Pour adresse et carte
            'illustrations',
            'presentation.descriptifCourt', 'presentation.descriptifDetaille',
            'ouverture.periodeEnClair', 'ouverture.precisionOuverture',
            'informations.languesParlees', 'informations.moyensCommunication', 'informations.urlReservation',
            'tarifs.tarifsEnClair', 'tarifs.modesPaiement',
            'prestations',
            'informationsHotellerie.classement', 'informationsHotelleriePleinAir.classement', // Pour étoiles
            'informationsHotellerie.labels', 'informationsHotelleriePleinAir.labels', // Pour labels
            'informationsHotellerie.capacite', 'informationsHotelleriePleinAir.capacite', // Pour capacités
            'informationsRestauration.capacite', 'informationsRestauration.classementsGuides' // Pour restos
        ]
    ): ?array {
        // === DEBUG: Log au début de la méthode (avec WARNING) ===
        $this->logger->warning('>>> Entering ' . __METHOD__);

        if (empty($selectionIds)) {
            $this->logger->warning(__METHOD__ . ' appelé sans selectionIds.');
            return null;
        }
        if (empty($this->apiKey) || $this->projectId <= 0) {
            $this->logger->error(__METHOD__ . ': Clé API/Projet ID non configuré.');
            return null;
        }

        $queryData = [
            'apiKey'         => $this->apiKey,
            'projetId'       => $this->projectId,
            'selectionIds'   => array_map('intval', $selectionIds),
            'count'          => max(1, $count), // Assurer count >= 1
            'responseFields' => $responseFields, // Utilise la liste passée ou la défaut ci-dessus
            'first'          => 0, // Pourrait être un argument si pagination nécessaire
            'order'          => 'NOM', // Trier par nom par défaut pour la liste
            'asc'            => true,
        ];

        $jsonQuery = json_encode($queryData);
        if ($jsonQuery === false) {
            $this->logger->error(__METHOD__ . ': Echec encodage JSON', ['error' => json_last_error_msg()]);
            return null;
        }

        $fullUrl = $this->searchApiUrl . '?query=' . urlencode($jsonQuery);
        $this->logger->info(__METHOD__ . ': Appel API Liste', ['url' => $this->searchApiUrl]);

        // Appel de la méthode centralisée pour exécuter la requête
        $decodedResponse = $this->executeApiRequest($fullUrl);

        // === DEBUG: Log de la structure du premier résultat (avec WARNING) ===
        if ($decodedResponse !== null && isset($decodedResponse['objetsTouristiques'])) {
             if (count($decodedResponse['objetsTouristiques']) > 0) {
                $firstObject = $decodedResponse['objetsTouristiques'][0];
                $logContext = [
                    'objectId' => $firstObject['id'] ?? 'N/A',
                    'objectType' => $firstObject['type'] ?? 'N/A',
                    'topLevelKeys' => array_keys($firstObject),
                    'localisationKeyExists' => isset($firstObject['localisation']),
                    'geolocalisationExists' => isset($firstObject['localisation']['geolocalisation']),
                    'geoJsonExists' => isset($firstObject['localisation']['geolocalisation']['geoJson']),
                    'coordinatesExist' => isset($firstObject['localisation']['geolocalisation']['geoJson']['coordinates'])
                ];
                 $this->logger->warning('>>> API Response - First Object Structure Check', $logContext);
             } else {
                  $this->logger->warning('>>> API Response - Aucun objet touristique retourné.');
             }
         } elseif ($decodedResponse !== null) {
              $this->logger->warning('>>> API Response - La clé "objetsTouristiques" est manquante.', ['responseKeys' => array_keys($decodedResponse)]);
         }
         // Pas de log si $decodedResponse est null, car executeApiRequest a déjà loggué l'erreur.
         // === FIN DEBUG ===

        return $decodedResponse; // Retourne le tableau complet décodé ou null
    }

    /**
     * Récupère un objet unique par son ID (via l'API de recherche pour l'instant).
     * NOTE: Idéalement, utiliser l'endpoint get-by-id s'il est disponible/configuré.
     *
     * @param int $objectId ID de l'objet Apidae
     * @return array|null Données de l'objet unique ou null si erreur/non trouvé
     */
    public function fetchObjectById(int $objectId): ?array
    {
        // === DEBUG: Log au début de la méthode (avec WARNING) ===
        $this->logger->warning('>>> Entering ' . __METHOD__, ['objectId' => $objectId]);

        if ($objectId <= 0) {
            $this->logger->warning(__METHOD__ . ' appelé avec ID invalide: ' . $objectId);
            return null;
        }
        if (empty($this->apiKey) || $this->projectId <= 0) {
            $this->logger->error(__METHOD__ . ': Clé API/Projet ID non configuré.');
            return null;
        }

        // Utiliser la même liste de champs que pour fetchObjectsBySelections par défaut,
        // car la vue détail a besoin d'au moins ces champs.
        // On pourrait définir une liste encore plus complète si nécessaire.
        $responseFields = [ 
            'id', 'nom', 'type', 
            'localisation', 'localisation.adresse', 'localisation.geolocalisation',
            'illustrations', 'presentation.descriptifCourt', 'presentation.descriptifDetaille',
            'ouverture.periodeEnClair', 'ouverture.precisionOuverture',
            'informations.languesParlees', 'informations.moyensCommunication', 'informations.urlReservation',
            'tarifs.tarifsEnClair', 'tarifs.modesPaiement', 'prestations',
            'informationsHotellerie.classement', 'informationsHotelleriePleinAir.classement',
            'informationsHotellerie.labels', 'informationsHotelleriePleinAir.labels',
            'informationsHotellerie.capacite', 'informationsHotelleriePleinAir.capacite',
            'informationsRestauration.capacite', 'informationsRestauration.classementsGuides'
        ];

        // Utilisation de 'identifiants' (tableau) pour filtrer par ID via l'API de recherche
        $queryData = [
            'apiKey'         => $this->apiKey,
            'projetId'       => $this->projectId,
            'identifiants'   => [$objectId], // Filtrer sur cet ID unique
            'responseFields' => $responseFields,
        ];

        $jsonQuery = json_encode($queryData);
        if ($jsonQuery === false) {
            $this->logger->error(__METHOD__ . ': Echec encodage JSON pour ID ' . $objectId, ['error' => json_last_error_msg()]);
            return null;
        }

        // Utiliser l'URL de recherche, car on filtre par 'identifiants'
        $fullUrl = $this->searchApiUrl . '?query=' . urlencode($jsonQuery);
        $this->logger->info(__METHOD__ . ': Appel API Détail (via recherche)', ['url' => $this->searchApiUrl, 'id' => $objectId]);

        // Exécution de la requête
        $response = $this->executeApiRequest($fullUrl);

        // Traitement de la réponse
        if ($response !== null && isset($response['objetsTouristiques']) && count($response['objetsTouristiques']) === 1) {
            $this->logger->info(__METHOD__ . ': Objet trouvé pour ID ' . $objectId);
            return $response['objetsTouristiques'][0]; // Retourne le premier (et unique) objet
        } elseif ($response !== null && isset($response['objetsTouristiques'])) {
             $this->logger->warning(__METHOD__ . ': Aucun objet trouvé pour ID ' . $objectId . ' via recherche.');
             return null;
        } else {
             // L'erreur a déjà été logguée par executeApiRequest
            $this->logger->error(__METHOD__ . ': Réponse API invalide ou échec requête pour ID ' . $objectId);
            return null;
        }
    }

    /**
     * Exécute la requête HTTP et décode la réponse JSON. Méthode privée.
     *
     * @param string $url URL complète de l'API à appeler
     * @return array|null Tableau associatif décodé ou null si erreur
     */
    private function executeApiRequest(string $url): ?array
    {
        try {
            $requestOptions = [
                'headers' => [
                    'Accept' => 'application/json',
                    'User-Agent' => 'TYPO3 Apidae Extension (cywolf_apidaetourisme)',
                ],
                'timeout' => 30,
                'allow_redirects' => true,
                'verify' => true, // IMPORTANT: garder à true en production
            ];

            // === DEBUG: Log de l'URL complète (attention si clé API dedans - PAS ICI car la clé est dans le JSON query) ===
            // $this->logger->debug(__METHOD__ . ': Requesting URL: ' . $url); // À utiliser avec prudence

            $response = $this->requestFactory->request($url, 'GET', $requestOptions);
            $statusCode = $response->getStatusCode();
            $content = $response->getBody()->getContents();

            // === Log du statut (avec WARNING pour visibilité) ===
            $this->logger->warning('>>> ' . __METHOD__ . ' - API Status Code Received: ' . $statusCode);

            if ($statusCode === 200) {
                 // === Log avant décodage (avec WARNING pour visibilité) ===
                 $this->logger->warning('>>> ' . __METHOD__ . ' - Status 200 OK. Attempting JSON decode.');

                $data = json_decode($content, true);
                if (json_last_error() === JSON_ERROR_NONE) {
                    return $data; // Succès, retourne les données décodées
                } else {
                    $this->logger->error('Failed to decode JSON response', ['jsonError' => json_last_error_msg(), 'responseSnippet' => substr($content, 0, 200)]);
                    return null; // Erreur de décodage
                }
            } else {
                // Erreur HTTP (non 200)
                $this->logger->error(__METHOD__ . ': Echec requête API HTTP', [
                    'urlBase' => $this->searchApiUrl, // Ne pas logger l'URL complète avec query
                    'statusCode' => $statusCode,
                    'responseSnippet' => mb_substr($content, 0, 500)
                ]);
                return null; // Erreur HTTP
            }
        } catch (\Throwable $e) { // Capture Exceptions et Errors
            $this->logger->error(__METHOD__ . ': Exception requête API', [
                 'urlBase' => $this->searchApiUrl,
                'message' => $e->getMessage(),
                'exceptionClass' => get_class($e),
                'trace' => $e->getTraceAsString() // Utile pour le debug avancé
            ]);
            return null; // Erreur durant la requête
        }
    }
}