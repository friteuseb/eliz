<?php
declare(strict_types=1);
namespace Cywolf\ApidaeTourisme\Command;

use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;
use Cywolf\ApidaeTourisme\Service\ApidaeService;
use Cywolf\ApidaeTourisme\Domain\Repository\EtablissementRepository;
use Cywolf\ApidaeTourisme\Domain\Model\Etablissement;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Core\DataHandling\SlugHelper;
use TYPO3\CMS\Extbase\Persistence\PersistenceManagerInterface;
use TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface;
use TYPO3\CMS\Core\Site\SiteFinder; 

class ApidaeImportCommand extends Command
{
    private ApidaeService $apidaeService;
    private EtablissementRepository $etablissementRepository;
    private PersistenceManagerInterface $persistenceManager;
    private ConfigurationManagerInterface $configurationManager; 
    private SiteFinder $siteFinder; 

    public function __construct(
        ApidaeService $apidaeService,
        EtablissementRepository $etablissementRepository,
        PersistenceManagerInterface $persistenceManager,
        ConfigurationManagerInterface $configurationManager,
        SiteFinder $siteFinder 
    ) {
        parent::__construct();
        $this->apidaeService = $apidaeService;
        $this->etablissementRepository = $etablissementRepository;
        $this->persistenceManager = $persistenceManager;
        $this->configurationManager = $configurationManager;
        $this->siteFinder = $siteFinder; 
    }

    protected function configure(): void
    {
        $this->setHelp('Importe/Met à jour les objets Apidae (ID, nom, slug) dans la DB locale.');
        $this->addArgument('selectionIds', InputArgument::OPTIONAL, 'Liste optionnelle d\'IDs de sélection Apidae (séparés par virgule) à importer.');
        $this->addArgument('storagePid', InputArgument::OPTIONAL, 'ID optionnel de la page de stockage (override le TypoScript).');
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);
        $io->title('Importation Apidae pour Slugs');

        // --- Récupérer la configuration ---
        $typoScriptSettings = $this->configurationManager->getConfiguration(
            ConfigurationManagerInterface::CONFIGURATION_TYPE_SETTINGS
            // Note: toujours sans clé d'extension ici, on suppose que ça fonctionne
        );

        // Storage PID
        $storagePid = (int)($input->getArgument('storagePid') ?: ($typoScriptSettings['persistence']['storagePid'] ?? 0));
        if ($storagePid <= 0) {
            $io->error('Le storagePid doit être défini via argument ou TypoScript (plugin.tx_cywolfapidaetourisme.persistence.storagePid)');
            return Command::FAILURE;
        }
        $io->writeln('Utilisation du Storage PID: ' . $storagePid);

        // Selection IDs
        $selectionIdsInput = $input->getArgument('selectionIds');
        if (!empty($selectionIdsInput)) {
             $selectionIds = GeneralUtility::intExplode(',', $selectionIdsInput, true);
        } else {
             $selectionIdsSetting = $typoScriptSettings['settings']['apidae']['selectionIds'] ?? '';
             $selectionIds = GeneralUtility::intExplode(',', $selectionIdsSetting, true);
        }

        if (empty($selectionIds)) {
             $io->error('Aucun ID de sélection Apidae défini via argument ou TypoScript (settings.apidae.selectionIds)');
             return Command::FAILURE;
        }
        $io->writeln('IDs de Sélection à traiter: ' . implode(', ', $selectionIds));

        // --- Initialisation SlugHelper ---
        // Récupérer la config de site pour la langue par défaut pour le slug
        // Note: Prend la première site configuration trouvée. Adaptez si multi-sites.
        $site = $this->siteFinder->getAllSites()[array_key_first($this->siteFinder->getAllSites())] ?? null;
        if (!$site) {
            $io->error("Impossible de trouver une configuration de site pour déterminer la langue du slug.");
            return Command::FAILURE;
        }
        $defaultLanguage = $site->getDefaultLanguage();
        // Configuration du SlugHelper
        $slugFieldName = 'slug';
        $slugConfig = $GLOBALS['TCA']['tx_cywolfapidaetourisme_domain_model_etablissement']['columns'][$slugFieldName]['config'] ?? [];
         $slugHelper = GeneralUtility::makeInstance(
             SlugHelper::class,
             'tx_cywolfapidaetourisme_domain_model_etablissement',
             $slugFieldName,
             $slugConfig['generatorOptions'] ?? []
         );

        // --- Récupération API ---
        // Récupérer *tous* les objets des sélections (augmenter le count)
        // Demander seulement 'id' et 'nom' pour l'import de slug
        $io->writeln('Appel API pour récupérer les objets...');
        // TODO: Gérer la pagination de l'API si > 1000 objets par exemple
        $apiResult = $this->apidaeService->fetchObjectsBySelections($selectionIds, 5000, ['id', 'nom']);

        if ($apiResult === null || !isset($apiResult['objetsTouristiques'])) {
            $io->error('Impossible de récupérer les objets depuis l\'API Apidae.');
            return Command::FAILURE;
        }
        $apiObjects = $apiResult['objetsTouristiques'];
        $io->writeln(count($apiObjects) . ' objets récupérés de l\'API.');

        // --- Traitement et Sauvegarde ---
        $countCreated = 0;
        $countUpdated = 0;
        $countSkipped = 0;

        foreach ($apiObjects as $apiObject) {
            $apidaeId = (int)($apiObject['id'] ?? 0);
            $name = trim($apiObject['nom']['libelleFr'] ?? '');

            if ($apidaeId <= 0 || empty($name)) {
                $io->warning('Objet API invalide ignoré (ID ou Nom manquant): ' . ($apiObject['id'] ?? 'N/A'));
                $countSkipped++;
                continue;
            }

            $existingRecord = $this->etablissementRepository->findOneByApidaeId($apidaeId);

            // Préparer les données pour le slug helper
            $recordData = [
                'pid' => $storagePid,
                'name' => $name
            ];

            if ($existingRecord) {
                $recordData['uid'] = $existingRecord->getUid(); 
                $newSlug = $slugHelper->generate($recordData, $storagePid);
                // Mise à jour seulement si le nom ou le slug a changé
                if ($existingRecord->getName() !== $name || $existingRecord->getSlug() !== $newSlug) {
                     $io->writeln(sprintf('Mise à jour ID %d : "%s" -> Slug "%s"', $apidaeId, $name, $newSlug));
                    $existingRecord->setName($name);
                    $existingRecord->setSlug($newSlug);
                    $this->etablissementRepository->update($existingRecord);
                    $countUpdated++;
                }
            } else {
                // Création
                $newSlug = $slugHelper->generate($recordData, $storagePid);
                $io->writeln(sprintf('Création ID %d : "%s" -> Slug "%s"', $apidaeId, $name, $newSlug));
                $newRecord = GeneralUtility::makeInstance(Etablissement::class);
                $newRecord->setPid($storagePid);
                $newRecord->setApidaeId($apidaeId);
                $newRecord->setName($name);
                $newRecord->setSlug($newSlug); 
                $this->etablissementRepository->add($newRecord);
                $countCreated++;
            }
        }

        // Persister tous les changements accumulés
        if ($countCreated > 0 || $countUpdated > 0) {
            $this->persistenceManager->persistAll();
            $io->writeln('Changements persistés en base de données.');
        } else {
            $io->writeln('Aucun changement à persister.');
        }

        $io->success(sprintf(
            'Import terminé. Créés: %d, Mis à jour: %d, Ignorés: %d',
            $countCreated,
            $countUpdated,
            $countSkipped
        ));
        return Command::SUCCESS;
    }
}