<?php
declare(strict_types=1);
namespace Cywolf\ApidaeTourisme\Domain\Repository;
use TYPO3\CMS\Extbase\Persistence\Repository;
use TYPO3\CMS\Extbase\Persistence\QueryInterface;

class EtablissementRepository extends Repository {
    public function findOneByApidaeId(int $apidaeId): ?Etablissement {
        $query = $this->createQuery();
        $query->getQuerySettings()->setRespectStoragePage(false);
        $query->matching($query->equals('apidaeId', $apidaeId));
        return $query->execute()->getFirst();
    }
    public function findByApidaeIds(array $apidaeIds): array {
        if (empty($apidaeIds)) { return []; }
        $query = $this->createQuery();
        $query->getQuerySettings()->setRespectStoragePage(false);
        $query->matching($query->in('apidaeId', $apidaeIds));
        $results = $query->execute(true); // Execute raw, maybe faster
        $indexedResults = [];
        foreach ($results as $record) {
            $indexedResults[$record['apidae_id']] = $this->mapSingleRow($record); // Map raw row to object
        }
        return $indexedResults;
   }
   // Helper to map raw row if needed (adjust based on your exact query needs)
   private function mapSingleRow(array $row): Etablissement {
        $object = $this->objectManager->get(Etablissement::class);
        $this->dataMapper->map(Etablissement::class, [$row])->rewind()->current();
        return $object; // This mapping part might need refinement
   }
}