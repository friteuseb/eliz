<?php
declare(strict_types=1);
namespace Cywolf\ApidaeTourisme\Domain\Model; // Vérifiez bien le namespace

use TYPO3\CMS\Extbase\DomainObject\AbstractEntity;

/**
 * Représente un établissement Apidae stocké localement pour le slug.
 */
class Etablissement extends AbstractEntity
{
    /**
     * ID Apidae unique
     * @var int
     */
    protected int $apidaeId = 0;

    /**
     * Nom de l'établissement
     * @var string
     */
    protected string $name = '';

    /**
     * Slug pour l'URL
     * @var string
     */
    protected string $slug = '';

    // --- Getters et Setters ---

    public function getApidaeId(): int
    {
        return $this->apidaeId;
    }

    public function setApidaeId(int $apidaeId): void
    {
        $this->apidaeId = $apidaeId;
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function setName(string $name): void
    {
        $this->name = $name;
    }

    public function getSlug(): string
    {
        return $this->slug;
    }

    public function setSlug(string $slug): void
    {
        $this->slug = $slug;
    }
}