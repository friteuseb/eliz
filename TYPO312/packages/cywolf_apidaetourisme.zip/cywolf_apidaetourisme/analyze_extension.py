#!/usr/bin/env python3
import os
import json
import re
import sys

# Définition du chemin de l'extension
extension_path = os.path.dirname(os.path.abspath(__file__))
print(f"Analyse de l'extension dans: {extension_path}")

# Vérification de la structure des dossiers
required_dirs = [
    'Classes',
    'Classes/Controller',
    'Classes/Domain/Model',
    'Classes/Domain/Repository',
    'Configuration',
    'Configuration/TCA/Overrides',
    'Resources/Private/Templates',
    'Resources/Private/Layouts',
]

print("\n=== Vérification de la structure des dossiers ===")
for dir_path in required_dirs:
    full_path = os.path.join(extension_path, dir_path)
    if os.path.isdir(full_path):
        print(f"✅ {dir_path} existe")
    else:
        print(f"❌ {dir_path} n'existe pas")

# Vérification des fichiers critiques
critical_files = [
    'ext_emconf.php',
    'ext_localconf.php',
    'ext_tables.php',
    'composer.json',
    'Configuration/TCA/Overrides/tt_content.php',
    'Classes/Controller/EtablissementController.php',
    'Resources/Private/Templates/Etablissement/List.html',
]

print("\n=== Vérification des fichiers critiques ===")
for file_path in critical_files:
    full_path = os.path.join(extension_path, file_path)
    if os.path.isfile(full_path):
        print(f"✅ {file_path} existe")
    else:
        print(f"❌ {file_path} n'existe pas")

# Analyse du composer.json
print("\n=== Analyse du composer.json ===")
composer_path = os.path.join(extension_path, 'composer.json')
try:
    with open(composer_path, 'r') as f:
        composer_data = json.load(f)
        print(f"Nom du package: {composer_data.get('name', 'Non défini')}")
        print(f"Namespace: {list(composer_data.get('autoload', {}).get('psr-4', {}).keys())[0] if composer_data.get('autoload', {}).get('psr-4') else 'Non défini'}")
        print(f"Extension key: {composer_data.get('extra', {}).get('typo3/cms', {}).get('extension-key', 'Non définie')}")
except Exception as e:
    print(f"Erreur lors de l'analyse du composer.json: {e}")

# Analyse de ext_emconf.php
print("\n=== Analyse de ext_emconf.php ===")
emconf_path = os.path.join(extension_path, 'ext_emconf.php')
try:
    with open(emconf_path, 'r') as f:
        content = f.read()
        title_match = re.search(r"'title'\s*=>\s*'([^']+)'", content)
        if title_match:
            print(f"Titre: {title_match.group(1)}")
        else:
            print("Titre: Non trouvé")
        
        version_match = re.search(r"'version'\s*=>\s*'([^']+)'", content)
        if version_match:
            print(f"Version: {version_match.group(1)}")
        else:
            print("Version: Non trouvée")
except Exception as e:
    print(f"Erreur lors de l'analyse de ext_emconf.php: {e}")

# Analyse de ext_localconf.php
print("\n=== Analyse de ext_localconf.php ===")
localconf_path = os.path.join(extension_path, 'ext_localconf.php')
try:
    with open(localconf_path, 'r') as f:
        content = f.read()
        plugin_match = re.search(r"configurePlugin\(\s*'([^']+)',\s*'([^']+)'", content)
        if plugin_match:
            print(f"Extension name: {plugin_match.group(1)}")
            print(f"Plugin name: {plugin_match.group(2)}")
        else:
            print("Configuration du plugin: Non trouvée")
except Exception as e:
    print(f"Erreur lors de l'analyse de ext_localconf.php: {e}")

# Analyse de tt_content.php
print("\n=== Analyse de tt_content.php ===")
tt_content_path = os.path.join(extension_path, 'Configuration/TCA/Overrides/tt_content.php')
try:
    with open(tt_content_path, 'r') as f:
        content = f.read()
        plugin_signature_match = re.search(r"\$pluginSignature\s*=\s*(?:str_replace\('[^']+', '[^']+', '[^']+'\)|'[^']+')", content)
        if plugin_signature_match:
            print(f"Plugin signature: {plugin_signature_match.group(0)}")
        else:
            print("Plugin signature: Non trouvée")
        
        add_plugin_match = re.search(r"addTcaSelectItem\(", content)
        if add_plugin_match:
            print("✅ addTcaSelectItem est utilisé")
        else:
            print("❌ addTcaSelectItem n'est pas utilisé")
except Exception as e:
    print(f"Erreur lors de l'analyse de tt_content.php: {e}")

print("\n=== Recommandations ===")
print("1. Assurez-vous que l'extension-key dans composer.json correspond au nom du dossier de l'extension.")
print("2. Dans ext_localconf.php, utilisez 'Cywolf.ApidaeTourisme' comme nom d'extension.")
print("3. Videz complètement tous les caches TYPO3 après chaque modification.")
print("4. Vérifiez que la structure des templates Fluid est correcte (Etablissement/List.html et Show.html).")
print("5. Vérifiez les permissions des fichiers et dossiers.")
