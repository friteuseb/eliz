<?php

// --- Configuration ---
$apiKey = 'k7mrsOXH';
$projectId = 4324; // Nombre entier

// Endpoint
$apiUrl = 'https://api.apidae-tourisme.com/api/v002/recherche/list-objets-touristiques';

// --- Tableau des paramètres ---
$queryData = [
    'apiKey'        => $apiKey,
    'projetId'      => $projectId,

    // *** MODIFICATION : Utiliser plusieurs IDs de sélection ***
    // Basé sur votre image (image_58afa3.png)
    'selectionIds'  => [
         90363, // Restauration Web VL
         88363, // Hôtellerie Web VL
         89142, // Campings Web VL
         // Ajoutez d'autres IDs de l'image ici si vous voulez combiner les résultats
         // 99989, // Résidences & Appart'hôtels Web VL
         // 99990, // Meublés de tourisme Web VL
         // 99991, // Jeux et activités Web VL
         // ... etc.
    ],

    'count'         => 10, // Augmenté pour voir des résultats de plusieurs sélections

    // *** CORRECTION : responseFields doit être un TABLEAU PHP de chaînes ***
    'responseFields'=> [
        'id',
        'nom',
        'localisation.adresse',
        'illustrations',
        'type', // Ajout du type pour mieux identifier les objets
        // Ajoutez d'autres champs ici si nécessaire, un par ligne/entrée de tableau
        // 'presentation.descriptifCourt',
    ],
    // 'asc'           => true, // Si vous avez besoin de trier
];

// --- Encodage JSON ---
$jsonQuery = json_encode($queryData);
if ($jsonQuery === false) {
    echo "Erreur d'encodage JSON : " . json_last_error_msg() . "\n";
    exit;
}

// --- Encodage URL ---
$urlEncodedJsonQuery = urlencode($jsonQuery);

// --- Construction URL ---
$fullUrl = $apiUrl . '?query=' . $urlEncodedJsonQuery;

echo "--- URL de la requête --- \n";
echo $fullUrl . "\n";

// Afficher le JSON qui sera envoyé, formaté pour la lisibilité (pour débogage)
echo "\n--- JSON Query envoyé (après json_encode, avant urlencode) --- \n";
echo json_encode($queryData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n\n";

// --- cURL (Reste identique) ---
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $fullUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Accept: application/json'));

// --- Exécution ---
echo "--- Exécution de la requête cURL --- \n";
$response = curl_exec($ch);

// --- Erreurs cURL ---
if (curl_errno($ch)) {
    echo 'Erreur cURL : ' . curl_error($ch) . "\n";
    curl_close($ch);
    exit;
}

// --- Statut HTTP ---
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
echo "Code de statut HTTP : " . $httpCode . "\n\n";

// --- Fermeture cURL ---
curl_close($ch);

// --- Traitement Réponse ---
echo "--- Réponse brute de l'API (joliment formatée si possible) --- \n";
$decodedResponse = json_decode($response);
if ($decodedResponse !== null) {
    echo json_encode($decodedResponse, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
} else {
    echo $response; // Afficher tel quel si ce n'est pas du JSON valide
}
echo "\n\n";

if ($httpCode == 200) {
    echo "--- Réponse JSON décodée (print_r du tableau PHP) --- \n";
    $data = json_decode($response, true); // 'true' pour obtenir un tableau associatif
    if (json_last_error() === JSON_ERROR_NONE) {
        print_r($data);
    } else {
        echo "Erreur lors du décodage JSON : " . json_last_error_msg() . "\n";
    }
} else {
    echo "La requête API a échoué (code: " . $httpCode . "). Vérifiez la construction de l'URL et les paramètres dans le JSON.\n";
    // La réponse brute est déjà affichée
}

?>